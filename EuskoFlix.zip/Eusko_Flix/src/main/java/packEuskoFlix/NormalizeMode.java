package packEuskoFlix;

public interface NormalizeMode {
	public Matrix normalizeMatrix();
	public Matrix unNormalizeMatrix(int pIdUser,Matrix pMatrix);
}
