package packEuskoFlix;

import java.util.HashMap;

public class Film {
	private int  id;
	private String title;
	//private HashMap<String, Integer> tags;
	
	public Film(int pId,String pTitle) {
		id = pId;
		title = pTitle;
	}
	public String getTitle() {
		return this.title;
	}
}
